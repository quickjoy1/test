# Lo-Fi Music Integration for Noise Generator

Add a fourth sound channel for Lo-Fi music to the existing Noise Generator with seamless support for both local audio (built-in curated tracks and user file uploads) and streaming audio (live web radio and YouTube live streams), configured via a dedicated modal to keep the card compact.

### User Review & Critical Decisions

> [!IMPORTANT]
> The following product decisions were confirmed during requirements clarification:
> - **Local Lo-Fi**: Provides high-quality built-in curated chill tracks alongside a custom local audio file uploader (MP3, WAV, OGG, M4A).
> - **Streaming Lo-Fi**: Supports both direct web radio streams (HTTPS audio feeds) and embedded YouTube live streams (e.g., Lofi Girl / Chillhop 24/7 streams).
> - **Card Geometry & Anti-Stretch Constraint**: The Noise Generator card remains strictly aligned with the adjacent ScratchPad by tightening row spacing (`gap-2.5`, `p-3.5`) and offloading source selection, custom URL inputs, and file management to a dedicated popup modal.

---

### 1. Overview & Core Concept

- **What It Does**: Enhances the session study screen's Noise Generator engine by introducing a fourth dedicated audio channel ("Lo-Fi Beats"). Users can mix ambient brown noise, rain, and ocean sounds together with relaxing Lo-Fi background music from either offline local sources or online streams.
- **Target Audience / Persona**: Students and focused knowledge workers who want all their background focus audio (ambient textures + chill beats) controllable from a single unified panel without having to keep separate music browser tabs open.
- **Key Value**: One-stop focus audio mixing without visual clutter or card height distortion in the session dashboard.

---

### 2. User Experience & Visual Design

- **Noise Generator Row Integration**:
  - Adds a fourth row styled with a warm purple/indigo aesthetic (`#8B5CF6` / `#A78BFA` tokens) that harmonizes with the amber (Brown), blue (Rain), and cyan (Ocean) rows.
  - Features a music icon (`Music` or `Radio`), channel title, volume slider, play/pause toggle, and a source configuration button (`SlidersHorizontal` / `ListMusic`) opening the Lo-Fi Options modal.
  - Tightens vertical padding and row spacing across all 4 rows (`p-3 sm:p-3.5`, `gap-2 sm:gap-2.5`) so the total height of the Noise Generator card matches the ScratchPad card on desktop viewports.

- **Lo-Fi Options Popup Modal (`LofiOptionsModal`)**:
  - **Clean Tabbed Source Navigation**:
    1. **Curated Tracks**: Pre-bundled relaxing lo-fi loops and chill beats with quick track switching and preview.
    2. **Local File**: Clean drag-and-drop zone with file picker for local `.mp3`, `.wav`, `.m4a`, or `.ogg` tracks; displays file name and playback status.
    3. **Web Radio Streams**: Curated 24/7 web radio stations (Lofi Hip Hop, Chillhop Cafe, Study Beats) plus an HTTPS audio stream URL input field.
    4. **YouTube Live**: Curated 24/7 study streams (Lofi Girl, Chillhop, Anime Chill) with preview player and custom YouTube video URL/ID input.
  - **No Mechanical Slop**: Clear title, human button labels ("Select Track", "Upload Audio", "Apply Stream"), and unboxed metadata separators (`·`).

- **Interactive Feedback**:
  - Play/pause state in the row triggers soft audio wave pulse animation matching the theme.
  - Seamless volume slider integration with live gain adjustment for both HTML5 audio and YouTube embeds.
  - Active source badge indicating current playback mode ("Curated", "Local File", "Web Radio", "YouTube").

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Dual Audio Pipeline (Tone.js/HTML5 Audio + YouTube IFrame API)**
  - *Chosen Approach*: Tone.js audio engine continues managing ambient noise (Brown, Rain, Ocean). For Lo-Fi music, HTML5 Audio with Web Audio API gain routing is used for curated tracks, local files, and web radio streams, while a hidden/compact iframe bridge manages YouTube streams with volume matching.
  - *Why*: Direct streaming of YouTube audio without video violates YouTube Terms of Service and is blocked by CORS. Using the standard YouTube IFrame API inside the popup modal or background iframe guarantees 100% reliable stream playback without broken proxies.
  - *Alternatives Considered*: Pure Web Audio synthesizers (limited musical variety) or scraping YouTube streams (brittle and frequently blocked).

- **Decision 2: Modal-Driven Source Selection**
  - *Chosen Approach*: Moving stream URLs, file pickers, and station switchers into a popup modal rather than expanding the row in-place.
  - *Why*: Satisfies the user's explicit requirement: "dont strech that area of noise generator add popup windows for more options if needed".
  - *Alternatives Considered*: Accordion expansion within the card (would distort the dashboard grid and cause layout shift against ScratchPad).

---

### 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                            SessionPage Dashboard                            │
│  ┌───────────────────────────────┐     ┌─────────────────────────────────┐  │
│  │          ScratchPad           │     │         NoiseGenerator          │  │
│  │   (Fixed height notes area)   │     │  ┌───────────────────────────┐  │  │
│  │                               │     │  │ Brown Noise Row           │  │  │
│  │                               │     │  │ Rain Sound Row            │  │  │
│  │                               │     │  │ Ocean Waves Row           │  │  │
│  │                               │     │  │ Lo-Fi Music Row (New)     │  │  │
│  │                               │     │  │  [Icon] [Title] [Slider]  │  │  │
│  │                               │     │  │  [Options Modal Button]   │  │  │
│  │                               │     │  └─────────────┬─────────────┘  │  │
│  └───────────────────────────────┘     └────────────────┼────────────────┘  │
└─────────────────────────────────────────────────────────┼───────────────────┘
                                                          │ Opens Modal
                                                          ▼
                                ┌───────────────────────────────────────────┐
                                │            LofiOptionsModal               │
                                │ ┌───────────────────────────────────────┐ │
                                │ │ Tabs: Curated | Local | Radio | YT    │ │
                                │ ├───────────────────────────────────────┤ │
                                │ │ - Curated Chill Beats Track List      │ │
                                │ │ - Local Audio File Picker (Blob/Data) │ │
                                │ │ - 24/7 Live Web Radio Stations + URL  │ │
                                │ │ - Curated YouTube Live + Video Input  │ │
                                │ └───────────────────────────────────────┘ │
                                └─────────────────────┬─────────────────────┘
                                                      │ Updates State
                                                      ▼
                                ┌───────────────────────────────────────────┐
                                │             LofiAudioEngine               │
                                │ - HTML5 Audio Node (Curated/Local/Radio)  │
                                │ - YouTube Player Controller               │
                                │ - Volume Normalization & Gain Routing     │
                                │ - LocalStorage Persistence for Settings   │
                                └───────────────────────────────────────────┘
```

- **State Management & Persistence**:
  - `lofiSourceType`: `'curated' | 'local' | 'radio' | 'youtube'` (persisted in `localStorage`).
  - `lofiVolume` & `lofiIsPlaying`: Persisted and synced with the Master Play/Pause toggle in NoiseGenerator.
  - `lofiSelectedTrack`: ID of curated track or URL of radio stream.
  - `lofiCustomRadioUrl` & `lofiCustomYoutubeUrl`: Saved in `localStorage` for immediate recall across study sessions.
  - `lofiLocalFileName`: Displays previously loaded file name.

- **Audio Lifecycle & Synchronization**:
  - "Play all" in NoiseGenerator starts both ambient textures and the active Lo-Fi source.
  - "Pause all" stops both ambient generators and the active Lo-Fi stream without losing the playback position or selected station.
  - Master limiter in `AudioEngine` ensures combined playback never causes digital clipping.
