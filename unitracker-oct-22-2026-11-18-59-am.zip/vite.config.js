import { compression } from 'vite-plugin-compression2';
import { defineConfig, loadEnv } from 'vite';
import path from "path";
import react from '@vitejs/plugin-react-swc';
import { VitePWA } from 'vite-plugin-pwa';
import { visualizer } from 'rollup-plugin-visualizer';

export default defineConfig(({ command, mode }) => {
  // Load env vars from .env files for server-side use (proxy middleware)
  loadEnv(mode, process.cwd(), '');

  // Disable compression for mobile builds
  const shouldDisableCompression = process.env.DISABLE_COMPRESSION === 'true' ||
                                  process.env.CAPACITOR_PLATFORM ||
                                  process.argv.some(arg => arg.includes('cap'));
  
  const isDev = command === 'serve';
  const isFastDev = process.env.FAST_DEV === 'true';
  const isReleaseBuild = mode === 'release';
  
  return {
    plugins: [
      react(),
      // Keep the PWA virtual module available, but skip Workbox generation for fast/mobile builds.
      VitePWA({
          disable: shouldDisableCompression || isFastDev,
          registerType: 'autoUpdate',
          includeAssets: [
            'assets/favicon.ico',
            'assets/apple-touch-icon-removebg-preview.png',
            'assets/android-chrome-192x192.png',
            'assets/android-chrome-512x512.png',
          ],
          manifest: {
            name: 'UniTracker 2026 - Study & Task Management',
            short_name: 'UniTracker',
            description: 'Free study app with Pomodoro timer, task management, and progress tracking for students.',
            theme_color: '#0A84FF',
            background_color: '#000000',
            display: 'standalone',
            orientation: 'portrait-primary',
            scope: '/',
            start_url: '/',
            icons: [
              {
                src: '/assets/android-chrome-192x192.png',
                sizes: '192x192',
                type: 'image/png',
              },
              {
                src: '/assets/android-chrome-512x512.png',
                sizes: '512x512',
                type: 'image/png',
              },
              {
                src: '/assets/android-chrome-512x512.png',
                sizes: '512x512',
                type: 'image/png',
                purpose: 'maskable',
              },
            ],
          },
          workbox: {
            globPatterns: ['**/*.{js,css,html,ico,png,svg,woff2}'],
            maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
            // Don't cache Supabase API calls or large chunks
            navigateFallback: '/index.html',
            navigateFallbackDenylist: [
              /^\/api\//,
            ],
            runtimeCaching: [
              {
                urlPattern: /\.(?:png|jpg|jpeg|svg|gif|webp|ico)$/,
                handler: 'CacheFirst',
                options: {
                  cacheName: 'images',
                  expiration: {
                    maxEntries: 60,
                    maxAgeSeconds: 60 * 60 * 24 * 30, // 30 days
                  },
                },
              },
              {
                urlPattern: /\.(?:js|css|woff2?)$/,
                handler: 'StaleWhileRevalidate',
                options: {
                  cacheName: 'static-resources',
                  expiration: {
                    maxEntries: 100,
                    maxAgeSeconds: 60 * 60 * 24 * 7, // 7 days
                  },
                },
              },
            ],
          },
          devOptions: {
            enabled: true,
            suppressWarnings: true,
          },
        }),
      // Bundle analyzer solo cuando se solicita explícitamente
      ...(process.env.ANALYZE === 'true' ? [
        visualizer({
          filename: 'dist/stats.html',
          open: true,
          gzipSize: true,
          brotliSize: true,
        })
      ] : []),
      // Compression is reserved for release builds because gzip + Brotli are expensive locally.
      ...(isReleaseBuild && !shouldDisableCompression ? [
        compression({
          algorithm: 'gzip',
          exclude: [/\.(br)$/, /\.(gz)$/],
        }),
        compression({
          algorithm: 'brotliCompress',
          exclude: [/\.(br)$/, /\.(gz)$/],
        }),
      ] : []),
    ],
    optimizeDeps: {
      include: [
        '@chakra-ui/react',
        '@emotion/react',
        '@emotion/styled',
        'react',
        'react-dom',
        'react-dom/client',
        'react-redux',
        '@reduxjs/toolkit',
        'framer-motion',
        'react-toastify',
        'lucide-react',
        '@supabase/supabase-js',
        '@supabase/postgrest-js',
        '@tiptap/react',
        '@tiptap/starter-kit',
        '@tiptap/extension-placeholder',
        'react/jsx-runtime',
        'react/jsx-dev-runtime',
        '@dayflow/core'
      ],
      exclude: [
        'chart.js'
      ],
      ...(isDev && !isFastDev && {
        esbuildOptions: {
          target: 'es2020',
          define: {
            global: 'globalThis',
          },
        },
      }),
    },
    build: {
      target: ['es2020', 'firefox91'],
      chunkSizeWarningLimit: 600,
      commonjsOptions: {
        transformMixedEsModules: true,
        include: [/node_modules/],
      },
      rollupOptions: {
        output: {
          manualChunks: (id) => {
            // Ensure React, React DOM, and JSX runtimes live together for stable exports
            if (id.includes('node_modules')) {
              if (
                id.includes('react/jsx-runtime') ||
                id.includes('react/jsx-dev-runtime') ||
                id.includes('react-dom') ||
                id.includes('scheduler') ||
                // match '/react/' but avoid matching unrelated packages with 'react' in path segments
                /[\\/]node_modules[\\/](react)[\\/]/.test(id)
              ) {
                return 'react-vendor';
              }
            }
          },
          entryFileNames: 'assets/[name]-[hash].js',
          chunkFileNames: 'assets/[name]-[hash].js',
          assetFileNames: 'assets/[name]-[hash].[ext]'
        }
      },
      sourcemap: isReleaseBuild,
      cssMinify: true,
      minify: isReleaseBuild ? 'terser' : 'esbuild',
      reportCompressedSize: false,
      modulePreload: {
        polyfill: false
      }
    },
    resolve: {
      alias: {
        "@": path.resolve(__dirname, "src"),
      },
      dedupe: ['react', 'react-dom', '@supabase/supabase-js', '@supabase/postgrest-js'],
      extensions: ['.mjs', '.js', '.ts', '.jsx', '.tsx', '.json']
    },
    server: {
      host: '0.0.0.0',
      port: 3000,
      strictPort: true,
      proxy: {
        '/api/openrouter': {
          target: 'http://localhost:3000',
          configure: (server) => {
            if (!server.middlewares) return;
            server.middlewares.use('/api/openrouter', async (req, res) => {
              if (req.method !== 'POST') {
                res.statusCode = 405;
                res.end(JSON.stringify({ error: 'Method not allowed' }));
                return;
              }
              let body = '';
              req.on('data', chunk => { body += chunk; });
              req.on('end', async () => {
                try {
                  const parsed = JSON.parse(body);
                  const apiKey = process.env.OPENROUTER_API_KEY;
                  if (!apiKey) {
                    res.statusCode = 500;
                    res.end(JSON.stringify({ error: 'OPENROUTER_API_KEY not configured in environment' }));
                    return;
                  }
                  const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                      'Authorization': `Bearer ${apiKey}`,
                      'HTTP-Referer': 'http://localhost:3000',
                    },
                    body: JSON.stringify({
                      model: parsed.model,
                      messages: parsed.messages,
                      temperature: parsed.temperature ?? 0.0,
                      stream: parsed.stream ?? false,
                    }),
                  });
                  const data = await response.text();
                  res.statusCode = response.status;
                  res.setHeader('Content-Type', 'application/json');
                  res.end(data);
                } catch (err) {
                  res.statusCode = 500;
                  res.end(JSON.stringify({ error: err.message }));
                }
              });
            });
          },
        },
        '/api/send-email': {
          target: 'http://localhost:3000',
          configure: (server) => {
            if (!server.middlewares) return;
            server.middlewares.use('/api/send-email', async (req, res) => {
              if (req.method !== 'POST') {
                res.statusCode = 405;
                res.end(JSON.stringify({ error: 'Method not allowed' }));
                return;
              }
              res.setHeader('Content-Type', 'application/json');
              const apiKey = process.env.RESEND_API_KEY;
              if (!apiKey) {
                res.statusCode = 500;
                res.end(JSON.stringify({ error: 'RESEND_API_KEY not configured in environment' }));
                return;
              }
              let body = '';
              req.on('data', chunk => { body += chunk; });
              req.on('end', async () => {
                try {
                  const parsed = JSON.parse(body);
                  const response = await fetch('https://api.resend.com/emails', {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                      'Authorization': `Bearer ${apiKey}`,
                    },
                    body: JSON.stringify({
                      from: `${parsed.config?.appName || 'UniTracker'} <${process.env.RESEND_FROM_EMAIL || 'onboarding@resend.dev'}>`,
                      to: parsed.to,
                      subject: `UniTracker Notification`,
                      html: `<p>Notification from UniTracker</p>`,
                    }),
                  });
                  const data = await response.text();
                  res.statusCode = response.status;
                  res.end(data);
                } catch (err) {
                  res.statusCode = 500;
                  res.end(JSON.stringify({ error: err.message }));
                }
              });
            });
          },
        },
      },
      watch: {
        usePolling: false,
        interval: 50,
        ignored: ['**/node_modules/**', '**/dist/**']
      },
      fs: {
        strict: false,
      }
    },
    preview: {
      port: 3000,
      host: '0.0.0.0'
    }
  };
});
