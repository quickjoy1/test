import { BookOpen, Briefcase, Check, ChevronDown, Coffee, FolderOpen, Gamepad2, Heart, Home, Moon, Music, Plane, Plus, Settings2, ShoppingBag, Smartphone, Star, Target, Trophy, Umbrella, User, Users, Wifi, Workflow, Zap } from 'lucide-react';
import { useEffect, useState } from 'react';

import { Github } from 'lucide-react';
import { Workspace } from '@/types/workspace';
import WorkspaceModal from '@/modals/WorkspaceModal';
import { useNavigation } from '@/navbar/NavigationContext';
import { useStudyState } from '@/store/appStore';
import useTheme from '@/hooks/useTheme';

interface FloatingFooterProps {
  workspaces?: (Workspace & { taskCount?: number })[];
  activeWorkspace?: (Workspace & { taskCount?: number }) | null;
  onSelectWorkspace?: (workspace: Workspace & { taskCount?: number }) => void;
  onCreateWorkspace?: (workspace: Workspace & { taskCount?: number }) => void;
  onEditWorkspace?: (workspace: Workspace & { taskCount?: number }) => void;
  onDeleteWorkspace?: (workspaceId: string) => void;
  onRefreshWorkspaces?: () => void;
  friends?: any[];
  currentUserId?: string;
}

const iconOptions: { [key: string]: React.ComponentType<any> } = {
  Briefcase,
  FolderOpen,
  Home,
  User,
  Users,
  Zap,
  BookOpen,
  Coffee,
  Gamepad2,
  Heart,
  Music,
  Plane,
  ShoppingBag,
  Smartphone,
  Star,
  Target,
  Trophy,
  Umbrella,
  Wifi,
  Workflow,
};

const formatTime = (seconds: number): string => {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  return `${m}:${s.toString().padStart(2, '0')}`;
};

const FloatingFooter: React.FC<FloatingFooterProps> = ({
  workspaces = [],
  activeWorkspace,
  onSelectWorkspace,
  onCreateWorkspace,
  onEditWorkspace,
  onDeleteWorkspace,
  onRefreshWorkspaces,
  friends = [],
  currentUserId,
}) => {
  const [showWorkspaceModal, setShowWorkspaceModal] = useState(false);
  const [showWorkspaceMenu, setShowWorkspaceMenu] = useState(false);
  const { currentTheme, toggleTheme } = useTheme();
  const { navigateTo } = useNavigation();
  const studyState = useStudyState();
  const [studyTime, setStudyTime] = useState(0);

  useEffect(() => {
    if (studyState.isRunning) {
      const interval = setInterval(() => {
        setStudyTime(prev => prev + 1);
      }, 1000);
      return () => clearInterval(interval);
    }
    return () => {};
  }, [studyState.isRunning]);

  useEffect(() => {
    if (!studyState.isRunning) {
      setStudyTime(studyState.time);
    }
  }, [studyState.isRunning, studyState.time]);

  useEffect(() => {
    if (!showWorkspaceMenu) return;
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setShowWorkspaceMenu(false);
    };
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [showWorkspaceMenu]);

  const handleQuickAddTask = () => {
    navigateTo('tasks');
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent('quickAddTask'));
    }, 300);
  };

  const showSessionTimer = studyState.isRunning || studyTime > 0;

  return (
    <>
      <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-[9999] max-w-[calc(100%-1rem)]">
        <div className="flex items-center gap-2 px-3 py-2 rounded-full border-2 border-[var(--border-primary)]/70 bg-[var(--bg-primary)]/70 backdrop-blur-[12px] shadow-[0_12px_30px_rgba(15,23,42,0.35)] text-[var(--text-secondary)]">
          {/* Workspace selector with task badge */}
          <button
            onClick={() => setShowWorkspaceMenu(prev => !prev)}
            className="flex items-center gap-2 hover:text-[var(--text-primary)] transition-colors"
            aria-label={`Workspace selector. Current workspace: ${activeWorkspace?.name || 'None'}. Click to open workspace selector.`}
            aria-expanded={showWorkspaceMenu}
            title={activeWorkspace?.name || 'Select Workspace'}
          >
            {(() => {
              const IconComp = iconOptions[activeWorkspace?.icon || 'Briefcase'] || Briefcase;
              return <IconComp className="w-4 h-4" />;
            })()}
            <span className="hidden sm:inline text-sm font-medium">
              {activeWorkspace?.name || 'Select Workspace'}
            </span>
            <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showWorkspaceMenu ? 'rotate-180' : ''}`} />
          </button>

          <span className="w-px h-4 bg-[var(--border-primary)]" aria-hidden="true" />

          <a
            href="https://discord.gg/8sRswbPQQm"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center w-7 h-7 rounded-full hover:bg-[var(--bg-secondary)] hover:text-[var(--text-primary)] transition-colors"
            aria-label="Discord"
          >
            <svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" aria-hidden="true">
              <title>Discord</title>
              <path fill="currentColor" d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z" />
            </svg>
          </a>

          <a
            href="https://github.com/rickypcyt/unitracker"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center w-7 h-7 rounded-full hover:bg-[var(--bg-secondary)] hover:text-[var(--text-primary)] transition-colors"
            aria-label="GitHub"
          >
            <Github className="w-4 h-4" />
          </a>

          <span className="w-px h-4 bg-[var(--border-primary)]" aria-hidden="true" />

          {/* Active Session Timer */}
          {showSessionTimer && (
            <>
              <span className="w-px h-4 bg-[var(--border-primary)]" aria-hidden="true" />
              <button
                onClick={() => navigateTo('session')}
                className="flex items-center gap-1.5 px-2 py-0.5 rounded-full hover:bg-[var(--bg-secondary)] hover:text-[var(--text-primary)] transition-colors"
                aria-label="Active study session"
                title="Go to study session"
              >
                <span className={`w-2 h-2 rounded-full ${studyState.isRunning ? 'bg-emerald-500 animate-pulse' : 'bg-[var(--text-secondary)]'}`} />
                <span className="text-xs font-mono tabular-nums text-[var(--text-primary)]">
                  {formatTime(studyTime)}
                </span>
              </button>
            </>
          )}


          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            className="flex items-center justify-center w-7 h-7 rounded-full hover:bg-[var(--bg-secondary)] hover:text-[var(--text-primary)] transition-colors"
            aria-label="Toggle theme"
            title="Toggle theme"
          >
            {currentTheme === 'dark' ? (
              <svg key="sun" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4 text-amber-400 animate-theme-icon"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2"></path><path d="M12 20v2"></path><path d="m4.93 4.93 1.41 1.41"></path><path d="m17.66 17.66 1.41 1.41"></path><path d="M2 12h2"></path><path d="M20 12h2"></path><path d="m6.34 17.66-1.41 1.41"></path><path d="m19.07 4.93-1.41 1.41"></path></svg>
            ) : (
              <Moon key="moon" className="w-4 h-4 animate-theme-icon" />
            )}
          </button>

          <span className="w-px h-4 bg-[var(--border-primary)]" aria-hidden="true" />

          {/* Quick Add Task */}
          <button
            onClick={handleQuickAddTask}
            className="flex items-center justify-center w-7 h-7 rounded-full hover:bg-[var(--bg-secondary)] hover:text-[var(--accent-primary)] transition-colors"
            aria-label="Quick add task"
            title="Quick add task"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Upward workspace menu — fixed to viewport so it stays centered on mobile */}
      {showWorkspaceMenu && (
        <>
          <div
            className="fixed inset-0 z-[9998]"
            onClick={() => setShowWorkspaceMenu(false)}
          />
          <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-[9999] w-64 max-w-[calc(100vw-2rem)] rounded-xl border-2 border-[var(--border-primary)] bg-[var(--bg-primary)] shadow-xl overflow-hidden">
            <div className="max-h-64 overflow-y-auto py-1">
              {[{
                id: 'all',
                name: 'All',
                icon: 'Workflow',
                taskCount: workspaces.reduce((sum, ws) => sum + (ws.taskCount || 0), 0),
              }, ...workspaces].map((ws) => {
                const isActive = activeWorkspace?.id === ws.id;
                const IconComp = iconOptions[ws.icon || 'Briefcase'] || Briefcase;
                return (
                  <button
                    key={ws.id}
                    onClick={() => {
                      setShowWorkspaceMenu(false);
                      try { localStorage.setItem('activeWorkspaceId', ws.id.toString()); } catch {}
                      onSelectWorkspace?.(ws);
                    }}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 text-left transition-colors ${
                      isActive
                        ? 'bg-[var(--accent-primary)]/10 text-[var(--accent-primary)]'
                        : 'text-[var(--text-primary)] hover:bg-[var(--bg-secondary)]'
                    }`}
                  >
                    <IconComp className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-[var(--accent-primary)]' : 'text-[var(--text-secondary)]'}`} />
                    <span className="flex-1 min-w-0 truncate text-sm font-medium">{ws.name}</span>
                    {(ws.taskCount ?? 0) > 0 && (
                      <span className="text-xs text-[var(--text-secondary)]">{ws.taskCount}</span>
                    )}
                    {isActive && <Check className="w-4 h-4 flex-shrink-0 text-[var(--accent-primary)]" />}
                  </button>
                );
              })}
            </div>
            <button
              onClick={() => {
                setShowWorkspaceMenu(false);
                setShowWorkspaceModal(true);
              }}
              className="w-full flex items-center gap-2.5 px-3 py-2.5 border-t border-[var(--border-primary)] text-sm font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-secondary)] transition-colors"
            >
              <Settings2 className="w-4 h-4" />
              Manage workspaces
            </button>
          </div>
        </>
      )}

      {/* Workspace Modal */}
      <WorkspaceModal
        isOpen={showWorkspaceModal}
        onClose={() => setShowWorkspaceModal(false)}
        workspaces={workspaces}
        activeWorkspace={activeWorkspace || null}
        onSelectWorkspace={onSelectWorkspace || (() => {})}
        onCreateWorkspace={onCreateWorkspace || (() => {})}
        onEditWorkspace={onEditWorkspace || (() => {})}
        onDeleteWorkspace={onDeleteWorkspace || (() => {})}
        {...(onRefreshWorkspaces && { onRefreshWorkspaces })}
        friends={friends}
        {...(currentUserId && { currentUserId })}
      />
    </>
  );
};

export default FloatingFooter;
