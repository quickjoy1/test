import { useCallback, useEffect, useRef, useState } from 'react';

// Helper function to do deep comparison of objects
const isEqual = (obj1: any, obj2: any) => {
  return JSON.stringify(obj1) === JSON.stringify(obj2);
};

interface ValidationRules {
  required?: boolean;
  minLength?: number;
  maxLength?: number;
  pattern?: RegExp;
  message?: string;
}

export const useFormState = (
  initialState: Record<string, any> = {},
  initialValidation: Record<string, ValidationRules> = {}
) => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isDirty, setIsDirty] = useState(false);
  const [hasInteracted, setHasInteracted] = useState(false);
  const prevInitialStateRef = useRef(initialState);

  // Reset form when initial state changes, but only if the actual values are different
  useEffect(() => {
    if (!isEqual(prevInitialStateRef.current, initialState)) {
      setFormData(initialState);
      setErrors({});
      setIsDirty(false);
      setHasInteracted(false);
      prevInitialStateRef.current = initialState;
    }
  }, [initialState]);

  const handleChange = useCallback((field: string, value: any) => {
    // Update form data
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));

    // Mark form as dirty and as interacted
    setIsDirty(prev => prev || true);
    setHasInteracted(true);

    // Clear error for this field if it exists
    setErrors(prev => {
      if (!prev[field]) return prev;
      const { [field]: _removed, ...rest } = prev;
      return rest;
    });
  }, []);

  const validateField = (field: string, value: string) => {
    const rules = initialValidation[field];
    if (!rules) return null;

    if (rules.required && (!value || value.trim() === '')) {
      return 'This field is required';
    }

    if (rules.minLength && value.length < rules.minLength) {
      return `Minimum length is ${rules.minLength} characters`;
    }

    if (rules.maxLength && value.length > rules.maxLength) {
      return `Maximum length is ${rules.maxLength} characters`;
    }

    if (rules.pattern && !rules.pattern.test(value)) {
      return rules.message || 'Invalid format';
    }

    return null;
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    let isValid = true;

    // Validate all fields
    Object.keys(initialValidation).forEach(field => {
      const error = validateField(field, formData[field]);
      if (error) {
        newErrors[field] = error;
        isValid = false;
      }
    });

    setErrors(newErrors);
    return isValid;
  };

  const resetForm = () => {
    setFormData(initialState);
    setErrors({});
    setIsDirty(false);
    setHasInteracted(false);
  };

  return {
    formData,
    errors,
    isDirty,
    hasInteracted,
    handleChange,
    validateForm,
    resetForm,
    setFormData
  };
};
