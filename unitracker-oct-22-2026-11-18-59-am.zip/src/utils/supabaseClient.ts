import { type SupabaseClient } from '@supabase/supabase-js';
import { createLocalSupabase } from '@/utils/localSupabase';

// The application runs 100% offline in local mode using in-browser localStorage.
// All tasks, workspaces, notes, study sessions, and habits are stored on device.
export const isSupabaseConfigured = false;

export const supabase: SupabaseClient = createLocalSupabase() as unknown as SupabaseClient;

